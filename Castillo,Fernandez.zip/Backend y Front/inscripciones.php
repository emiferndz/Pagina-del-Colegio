<?php
session_start();
include('conexion.php');

// Verificar si el usuario está logeado
if (!isset($_SESSION['id'])) {
    header("Location: login.php");
    exit();
}

$nombre_usuario = $_SESSION['nombre'];

// Obtener valores para filtros
$actividad_nombre = isset($_POST['actividad_nombre']) ? $_POST['actividad_nombre'] : '';
$escuela_nombre = isset($_POST['escuela_nombre']) ? $_POST['escuela_nombre'] : '';
$curso = isset($_POST['curso']) ? $_POST['curso'] : '';

// Consulta para obtener las inscripciones con los filtros aplicados
$consulta_inscripciones = "
SELECT 
    u.nombre AS usuario_nombre, 
    u.apellido AS usuario_apellido, 
    c.curso, 
    e.nombre AS escuela_nombre, 
    a.nombre AS actividad_nombre 
FROM 
    inscripciones i
INNER JOIN 
    usuarios u ON i.usuario_id = u.id
INNER JOIN 
    Curso c ON u.id_curso = c.id
INNER JOIN 
    Escuela e ON u.id_escuela = e.id
INNER JOIN 
    actividades a ON i.actividad_id = a.id
WHERE 
    a.nombre LIKE '%$actividad_nombre%' AND
    e.nombre LIKE '%$escuela_nombre%' AND
    c.curso LIKE '%$curso%'
ORDER BY 
    a.nombre ASC";

$resultado_inscripciones = $conn->query($consulta_inscripciones);

// Consulta para obtener las opciones de los filtros
$consulta_actividades = "SELECT DISTINCT nombre FROM actividades";
$consulta_escuelas = "SELECT DISTINCT nombre FROM Escuela";
$consulta_cursos = "SELECT DISTINCT curso FROM Curso";

$resultado_actividades = $conn->query($consulta_actividades);
$resultado_escuelas = $conn->query($consulta_escuelas);
$resultado_cursos = $conn->query($consulta_cursos);

?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Inscripciones</title>
    <link href="https://cdnjs.cloudflare.com/ajax/libs/materialize/1.0.0/css/materialize.min.css" rel="stylesheet">
    <link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
    <link rel="stylesheet" href="./css/StyleDash.css">
    <link rel="icon" href="./img/logo.png" sizes="32x32">
</head>
<body>
<!-- Navbar -->
<?php include 'header.php'; ?>


<main>
<div class="container table-container">
        <h3>Inscripciones</h3>
        <!-- Formulario de filtro -->



    <form method="POST" action="">
    <div class="row">
            <div class="input-field col s4">
                <select id="actividad_nombre" name="actividad_nombre">
                    <option value="" disabled selected>Seleccione Actividad</option>
                    <?php while ($row = $resultado_actividades->fetch_assoc()): ?>
                        <option value="<?php echo htmlspecialchars($row['nombre']); ?>" <?php echo ($row['nombre'] == $actividad_nombre) ? 'selected' : ''; ?>>
                            <?php echo htmlspecialchars($row['nombre']); ?>
                        </option>
                    <?php endwhile; ?>
                </select>
                <label>Actividad</label>
            </div>
            <div class="input-field col s4">
                <select id="escuela_nombre" name="escuela_nombre">
                    <option value="" disabled selected>Seleccione Escuela</option>
                    <?php while ($row = $resultado_escuelas->fetch_assoc()): ?>
                        <option value="<?php echo htmlspecialchars($row['nombre']); ?>" <?php echo ($row['nombre'] == $escuela_nombre) ? 'selected' : ''; ?>>
                            <?php echo htmlspecialchars($row['nombre']); ?>
                        </option>
                    <?php endwhile; ?>
                </select>
                <label>Escuela</label>
            </div>
            <div class="input-field col s4">
                <select id="curso" name="curso">
                    <option value="" disabled selected>Seleccione Curso</option>
                    <?php while ($row = $resultado_cursos->fetch_assoc()): ?>
                        <option value="<?php echo htmlspecialchars($row['curso']); ?>" <?php echo ($row['curso'] == $curso) ? 'selected' : ''; ?>>
                            <?php echo htmlspecialchars($row['curso']); ?>
                        </option>
                    <?php endwhile; ?>
                </select>
                <label>Curso</label>
            </div>
            <button type="submit" class="btn">Filtrar</button>
            <a href="exportar_pdf.php?actividad_nombre=<?php echo urlencode($actividad_nombre); ?>&escuela_nombre=<?php echo urlencode($escuela_nombre); ?>&curso=<?php echo urlencode($curso); ?>" class="btn" target="_blank">Generar PDF</a>
       
            </div>
        </form>
    </div>

       
        <table class="striped container">
            <thead>
                <tr>
                    <th>Nombre</th>
                    <th>Apellido</th>
                    <th>Curso</th>
                    <th>Escuela</th>
                    <th>Actividad</th>
                </tr>
            </thead>
            <tbody>
                <?php
                if ($resultado_inscripciones->num_rows > 0) {
                    while ($row = $resultado_inscripciones->fetch_assoc()) {
                        echo '<tr>';
                        echo '<td>' . htmlspecialchars($row['usuario_nombre']) . '</td>';
                        echo '<td>' . htmlspecialchars($row['usuario_apellido']) . '</td>';
                        echo '<td>' . htmlspecialchars($row['curso']) . '</td>';
                        echo '<td>' . htmlspecialchars($row['escuela_nombre']) . '</td>';
                        echo '<td>' . htmlspecialchars($row['actividad_nombre']) . '</td>';
                        echo '</tr>';
                    }
                } else {
                    echo '<tr><td colspan="5" class="center-align">No hay inscripciones disponibles.</td></tr>';
                }
                ?>
            </tbody>
        </table>
    </div>

</main>
<?php include 'footer.php'; ?>

    <!-- Scripts de Materialize -->
    <script src="https://cdnjs.cloudflare.com/ajax/libs/materialize/1.0.0/js/materialize.min.js"></script>
    <script>
        document.addEventListener('DOMContentLoaded', function() {
            var selectElems = document.querySelectorAll('select');
            M.FormSelect.init(selectElems, {});
        });
    </script>
    <script>
        document.addEventListener('DOMContentLoaded', function() {
            var sidenavElems = document.querySelectorAll('.sidenav');
            var sidenavInstances = M.Sidenav.init(sidenavElems, {});

            var dropdownElems = document.querySelectorAll('.dropdown-trigger');
            var dropdownInstances = M.Dropdown.init(dropdownElems, {
                hover: false  // Para activar el dropdown al hacer clic
            });
        });
    </script>
</body>
</html>

<?php
$conn->close();
?>
