<?php
session_start();

// Verificar si el usuario está logeado
if (!isset($_SESSION['id'])) {
    header("Location: login.php");
    exit();
}

//$nombre_usuario = $_SESSION['nombre'] . " " . $_SESSION['apellido'];
$nombre_usuario = $_SESSION['nombre'];
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Index</title>
    <link href="https://cdnjs.cloudflare.com/ajax/libs/materialize/1.0.0/css/materialize.min.css" rel="stylesheet">
    <link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
    <link rel="stylesheet" href="./css/StyleDash.css">
    <link rel="icon" href="./img/logo.png" sizes="32x32">
</head>
<body>
    <!-- Navbar -->

    <?php include 'header.php'; ?>

    <!-- Contenido Principal -->
<main>
    <div class="container">
        <h4 class="center-align">Colegio San José Córdoba</h4>
        <h5 class="center-align">Creado por Castillo y Fernández</h5>
        <div class="row rowIndex">

            <!-- Primera tarjeta en una columna -->
            <div class="col s12 m4"> <!-- Utilizando el sistema de cuadrícula de Materialize CSS: s12 para móvil, m6 para tamaño mediano -->
                <div class="card">
                    <div class="card-image waves-effect waves-block waves-light">
                        <img class="activator" src="./img/img_01.jpg">
                    </div>
                    <div class="card-content">
                        <span class="card-title activator grey-text text-darken-4">Nivel Inicial<i class="material-icons right">more_vert</i></span>
                       <!--<p class="texto-link"><a href="#">ninicial@colegiodesanjose.edu.ar</a></p>-->
                    </div>
                    <div class="card-reveal">
                        <span class="card-title grey-text text-darken-4">Nivel Inicial<i class="material-icons right">close</i></span>
                        <p>Nuestro carisma y hacer cotidiano, se sustenta en la formación en valores humanos, evangélicos, sociales que van determinando  modos de vincularse.</p>
                    </div>
                </div>
            </div>

             <!-- Primera tarjeta en una columna -->
             <div class="col s12 m4"> <!-- Utilizando el sistema de cuadrícula de Materialize CSS: s12 para móvil, m6 para tamaño mediano -->
                <div class="card">
                    <div class="card-image waves-effect waves-block waves-light">
                        <img class="activator" src="./img/img_02.jpg">
                    </div>
                    <div class="card-content">
                        <span class="card-title activator grey-text text-darken-4">Nivel Primario<i class="material-icons right">more_vert</i></span>
                        <!--<p class="texto-link"><a href="nprimario@colegiodesanjose.edu.ar">nprimario@colegiodesanjose.edu.ar</a></p>-->
                    </div>
                    <div class="card-reveal">
                        <span class="card-title grey-text text-darken-4">Nivel Primario<i class="material-icons right">close</i></span>
                        <p>Nuestra Comunidad Educativa trabaja la identidad pedagógico-pastoral atendiendo el carisma institucional, los propósitos fundacionales, tratando de leer los signos del presente para orientar la evangelización de la cultura actual.</p>
                    </div>
                </div>
            </div>

            <!-- Segunda tarjeta en otra columna -->
            <div class="col s12 m4"> <!-- Utilizando el sistema de cuadrícula de Materialize CSS: s12 para móvil, m6 para tamaño mediano -->
                <div class="card">
                    <div class="card-image waves-effect waves-block waves-light">
                        <img class="activator" src="./img/img_03.jpg">
                    </div>
                    <div class="card-content">
                        <span class="card-title activator grey-text text-darken-4">Nivel Secundario<i class="material-icons right">more_vert</i></span>
                      <!--<p class="texto-link"><a href="#">direccionsecundario@colegiodesanjose.edu.ar</a></p>-->
                      </div>
                    <div class="card-reveal">
                        <span class="card-title grey-text text-darken-4">Nivel Secundario<i class="material-icons right">close</i></span>
                        <p>En nuestra escuela San José la educación secundaria responde a una tarea evangelizadora que fomenta en nuestros alumnos una visión comprometida y transformadora del medio ambiente natural y social.</p>
                    </div>
                </div>
            </div>

        </div>
    </div>
</main>

<?php include 'footer.php'; ?>

    <!-- Scripts -->
    <script src="https://cdnjs.cloudflare.com/ajax/libs/materialize/1.0.0/js/materialize.min.js"></script>

    <script>
        document.addEventListener('DOMContentLoaded', function() {
            var sidenavElems = document.querySelectorAll('.sidenav');
            var sidenavInstances = M.Sidenav.init(sidenavElems, {});

            var dropdownElems = document.querySelectorAll('.dropdown-trigger');
            var dropdownInstances = M.Dropdown.init(dropdownElems, {
                hover: false  // Para activar el dropdown al hacer clic
            });
        });
    </script>

</body>

</html>


