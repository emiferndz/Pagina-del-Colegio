<footer class="footerColor footerContainer">
        <div class="container footerContainer">
        <div class="row footerColor center footerContainer">
            <div class="col l6 s12">
                <a href="index.php" class="brand-logo">
                    <div class="logofooterDiv">
                        <img src="./img/logo.png" alt="Logo San Jose" class="logofooter">
                        <span class="username"><h5 class="amber-text text-accent-3">Colegio de San José</h5></span>
                    </div>
                </a>
                <p class="grey-text text-lighten-4">Independencia 302. X5000 - Córdoba Argentina</p>
            </div>
            <div class="col l4 offset-l2 s12">
            <h6 class="white-text">0351 - 4223428</h6>
            <ul>
                <li><a class="grey-text text-lighten-3 texto-en-minusculas texto-chico" href="#!">ninicial@colegiodesanjose.edu.ar</a></li>
                <li><a class="grey-text text-lighten-3 texto-en-minusculas texto-chico" href="#!">nprimario@colegiodesanjose.edu.ar</a></li>
                <li><a class="grey-text text-lighten-3 texto-en-minusculas texto-chico" href="#!">direccionsecundario@colegiodesanjose.edu.ar</a></li>
            </ul>
            </div>
            <p class="grey-text text-lighten-4">© 2024 Copyright-informatica San José</p>
        </div>
        </div>
</footer>