


<header>

  
<nav>
        <div class="nav-wrapper">
            <a href="index.php" class="brand-logo">
                <div class="logoflex">
                    <img src="./img/logo.png" alt="Logo San Jose" class="logo2">
                    <span class="username"><?php echo $nombre_usuario; ?>.</span>
                </div>
            </a>
            <a href="#" data-target="mobile-demo" class="sidenav-trigger"><i class="material-icons">add</i></a>
            <ul class="right hide-on-med-and-down">
                <li><a href="index.php">Inicio</a></li>
                <li><a href="dashboard.php">Eventos</a></li>
                <li><a href="inscripciones.php">Inscripciones</a></li>
                <li><a href="resutados.php">Resultados</a></li>
                <li><a href="fechas.php">Fechas</a></li>
                <li><a class="dropdown-trigger" href="#!" data-target="dropdown1">Menu<i class="material-icons right">arrow_drop_down</i></a></li>
                <li><a href="logout.php">Cerrar sesión</a></li>
            </ul>
        </div>
    </nav>
                <!-- Dropdown Structure -->
                <ul id="dropdown1" class="dropdown-content colorDropdown">
                    <li><a href="crud.php">Registro</a></li>
                    <li class="divider"></li>
                    <li><a href="perfil.php">Perfil</a></li>
                </ul>

                <!-- Dropdown Structure -->
                <ul id="dropdown2" class="dropdown-content colorDropdown">
                    <li><a href="crud.php">Registro</a></li>
                    <li class="divider"></li>
                    <li><a href="perfil.php">Perfil</a></li>
                </ul>

    <!-- Sidebar (Sidenav) -->
    <ul class="sidenav" id="mobile-demo">
        <li>
            <div class="user-view">
                <a href="#user" class="LogoSidebar"><img class="Sidebar" src="./img/logo.png"></a>
                <a href="#name"><span class="white-text name"><?php echo $nombre_usuario; ?></span></a>
            </div>
        </li>
        <li><a href="index.php">Inicio</a></li>
        <li><a href="dashboard.php">Eventos</a></li>
        <li><a href="inscripciones.php">Inscripciones</a></li>
        <li><a href="resutados.php">Resultados</a></li>
        <li><a href="fechas.php">Fechas</a></li>
        <li><a class="dropdown-trigger" href="#!" data-target="dropdown2">Menu<i class="material-icons right">arrow_drop_down</i></a></li>
        <li><a href="logout.php" class="waves-effect">Cerrar sesión</a></li>
    </ul>

</header>