<?php
session_start();

// Verificar si el usuario está logeado
if (!isset($_SESSION['id'])) {
    header("Location: login.php");
    exit();
}

//$nombre_usuario = $_SESSION['nombre'] . " " . $_SESSION['apellido'];
$nombre_usuario = $_SESSION['nombre'];
include('conexion.php');

// Consultar las actividades del tipo 'organizador'
$consulta_actividades = "SELECT a.id, a.nombre, a.descripcion, a.fecha_inicio, a.fecha_fin, a.cupo, u.nombre as organizador_nombre, a.imagen
                         FROM actividades a
                         INNER JOIN usuarios u ON a.organizador_id = u.id
                         WHERE a.fecha_inicio >= CURDATE()
                         ORDER BY a.fecha_inicio ASC"; 
$resultado_actividades = $conn->query($consulta_actividades);

?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dashboard</title>
    <link href="https://cdnjs.cloudflare.com/ajax/libs/materialize/1.0.0/css/materialize.min.css" rel="stylesheet">
    <link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
    <link rel="stylesheet" href="./css/StyleDash.css">
    <link rel="icon" href="./img/logo.png" sizes="32x32">
</head>
<body>
    <!-- Navbar -->
    <?php include 'header.php'; ?>

    <!-- Contenido Principal -->
    <main>
    <div class="container">
        <h4 class="center-align">Actividades de Organizador</h4>
        <div class="row rowDashboar">
            <?php
            if ($resultado_actividades->num_rows > 0) {
                while ($row = $resultado_actividades->fetch_assoc()) {
                    echo '<div class="col s12 m4">';
                    echo '<div class="card">';
                    echo '<div class="card-image">';
                    echo '<img src="./img/' . htmlspecialchars($row['imagen']) . '" class="actividad-imagen">';
     
   
                    echo '</div>';
                    echo '<div class="card-content">';
                    echo '<h5 class="  black-text">' . htmlspecialchars($row['nombre']) . '</h5>';
                    echo '<p>' . htmlspecialchars($row['descripcion']) . '</p>';
                    echo '<p>Fecha de inicio: ' . htmlspecialchars($row['fecha_inicio']) . '</p>';
                    echo '<p>Fecha de fin: ' . htmlspecialchars($row['fecha_fin']) . '</p>';
                    echo '<p>Cupo: ' . htmlspecialchars($row['cupo']) . '</p>';
                    echo '<p>Organizador: ' . htmlspecialchars($row['organizador_nombre']) . '</p>';
                    echo '</div>';
                    echo '</div>';
                    echo '</div>';
                }
            } else {
                echo '<p class="center-align">No hay actividades disponibles.</p>';
            }
            ?>
        </div>

        <div class="center-align">
            <a href="actividades_disponibles.php" class="btn btn-custom waves-effect waves-light">Inscribirse</a>
        </div>
    </div>
</main>
<?php include 'footer.php'; ?>


    <!-- Scripts -->
    <script src="https://cdnjs.cloudflare.com/ajax/libs/materialize/1.0.0/js/materialize.min.js"></script>
    <script>
        document.addEventListener('DOMContentLoaded', function() {
            var sidenavElems = document.querySelectorAll('.sidenav');
            var sidenavInstances = M.Sidenav.init(sidenavElems, {});

            var dropdownElems = document.querySelectorAll('.dropdown-trigger');
            var dropdownInstances = M.Dropdown.init(dropdownElems, {
                hover: false  // Para activar el dropdown al hacer clic
            });
        });
    </script>
    
</body>
</html>

<?php
$conn->close();
?>
