


<header>
    <nav>
        <div class="nav-wrapper">
            <a href="index.php" class="brand-logo">
                <div class="logoflex">
                    <img src="./img/logo.png" alt="Logo San José" class="logo2" style="width: 40px; height: auto;">
                </div>
            </a>
            <a href="#" data-target="mobile-demo" class="sidenav-trigger"><i class="material-icons">menu</i></a>
            <ul class="right hide-on-med-and-down">
                <li><a href="login.php">Login</a></li>
            </ul>
        </div>
    </nav>

    <!-- Sidebar (Sidenav) -->
    <ul class="sidenav" id="mobile-demo">
        <li>
            <div class="user-view">
                <a href="#user" class="LogoSidebar"><img class="Sidebar" src="./img/logo.png"></a>
            </div>
        </li>
        <li><a href="login.php">Login</a></li>
    </ul>
</header>
