<?php
session_start();

// Verificar si el usuario está logeado
if (!isset($_SESSION['id'])) {
    header("Location: login.php");
    exit();
}
$nombre_usuario = $_SESSION['nombre'];
// Incluir archivo de conexión
include 'conexion.php';

// Obtener los datos del usuario logueado
$id_usuario = $_SESSION['id'];
$sql = "SELECT nombre, apellido, email, telefono FROM usuarios WHERE id = ?";
$stmt = $conn->prepare($sql);
$stmt->bind_param("i", $id_usuario);
$stmt->execute();
$stmt->bind_result($nombre, $apellido, $email, $telefono);
$stmt->fetch();
$stmt->close();
$conn->close();
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Perfil</title>
    <link href="https://cdnjs.cloudflare.com/ajax/libs/materialize/1.0.0/css/materialize.min.css" rel="stylesheet">
    <link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
    <link rel="stylesheet" href="./css/StyleDash.css">
    <link rel="icon" href="./img/logo.png" sizes="32x32">
</head>
<body>
    <!-- Navbar -->
    <?php include 'header.php'; ?>

    <!-- Contenido Principal -->
    <main>
        <div class="container">
            <h4 class="center-align">Perfil del Usuario</h4>
            <div class="row">
                <div class="col s12 m6 offset-m3">
                    <div class="card">
                        <div class="card-content">
                            <span class="card-title">Información Personal</span>
                            <p><strong>Nombre:</strong> <?php echo htmlspecialchars($nombre); ?></p>
                            <p><strong>Apellido:</strong> <?php echo htmlspecialchars($apellido); ?></p>
                            <p><strong>Email:</strong> <?php echo htmlspecialchars($email); ?></p>
                            <p><strong>Teléfono:</strong> <?php echo htmlspecialchars($telefono); ?></p>
                        </div>
                        <div class="card-action">
                            <a href="cambiar_password.php">Cambiar Contraseña</a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </main>
    <?php include 'footer.php'; ?>
    <!-- Scripts -->
    <script src="https://cdnjs.cloudflare.com/ajax/libs/materialize/1.0.0/js/materialize.min.js"></script>
    <script>
        document.addEventListener('DOMContentLoaded', function() {
            var sidenavElems = document.querySelectorAll('.sidenav');
            var sidenavInstances = M.Sidenav.init(sidenavElems, {});

            var dropdownElems = document.querySelectorAll('.dropdown-trigger');
            var dropdownInstances = M.Dropdown.init(dropdownElems, {
                hover: false  // Para activar el dropdown al hacer clic
            });
        });
    </script>
</body>
</html>
