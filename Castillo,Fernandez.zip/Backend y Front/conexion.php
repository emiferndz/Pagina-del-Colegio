<?php
// datos conexión
$servername = "localhost:3306";
$username = "root";
$password = "";
$dbname = "evento";


// Crear conexión
$conn = new mysqli($servername, $username, $password, $dbname);

// Verificar conexión
if ($conn->connect_error) {
    die("Conexión fallida:  " . $conn->connect_error);
}
?>
