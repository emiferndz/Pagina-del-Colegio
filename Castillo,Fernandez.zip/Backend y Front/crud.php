<?php
session_start();
include('conexion.php');

// Verificar si el usuario ha iniciado sesión
if (!isset($_SESSION['id'])) {
    header("Location: login.php");
    exit();
}

// Verificar el tipo de usuario
$id_TipoUsuarios = $_SESSION['id_TipoUsuarios'];
if ($id_TipoUsuarios != 3) {
    header("Location: index.php");
    exit();
}

$nombre_usuario = $_SESSION['nombre'];

// Función para obtener datos de cualquier tabla
function obtenerDatos($conn, $tabla) {
    $consulta = "SELECT * FROM $tabla";
    return $conn->query($consulta);
}

// Obtener la tabla seleccionada
$tabla_seleccionada = isset($_POST['tabla']) ? $_POST['tabla'] : 'actividades';

// Si se realiza una acción POST (como eliminar o editar), redirigir después del procesamiento
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Procesar acciones como eliminar o editar aquí
    if (isset($_POST['accion']) && $_POST['accion'] == 'eliminar' && isset($_POST['id'])) {
        $id = $_POST['id'];
        $tabla = $_POST['tabla'];
        
        try {
            // Utilizar consultas preparadas para mayor seguridad
            $stmt = $conn->prepare("DELETE FROM $tabla WHERE id = ?");
            $stmt->bind_param("i", $id);
            $stmt->execute();
            $stmt->close();
        } catch (Exception $e) {
            echo "Error al eliminar el registro: " . $e->getMessage();
        }
        
        header("Location: crud.php?tabla=$tabla");
        exit();
    }
}

$datos = obtenerDatos($conn, $tabla_seleccionada);
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Gestión de Tablas</title>
    <link href="https://cdnjs.cloudflare.com/ajax/libs/materialize/1.0.0/css/materialize.min.css" rel="stylesheet">
    <link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
    <link rel="stylesheet" href="./css/StyleDash.css">
    <link rel="icon" href="./img/logo.png" sizes="32x32">
</head>
<body>
<header>
    <nav>
        <div class="nav-wrapper">
            <a href="index.php" class="brand-logo">
                <div class="logoflex">
                    <img src="./img/logo.png" alt="Logo San Jose" class="logo2">
                    <span class="username"><?php echo htmlspecialchars($nombre_usuario); ?>.</span>
                </div>
            </a>
            <a href="#" data-target="mobile-demo" class="sidenav-trigger"><i class="material-icons">add</i></a>
            <ul class="right hide-on-med-and-down">
                <li><a href="index.php">Inicio</a></li>
                <li><a href="dashboard.php">Eventos</a></li>
                <li><a href="inscripciones.php">Inscripciones</a></li>
                <li><a href="resutados.php">Resultados</a></li>
                <li><a href="fechas.php">Fechas</a></li>
                <li><a class="dropdown-trigger" href="#!" data-target="dropdown1">Menu<i class="material-icons right">arrow_drop_down</i></a></li>
                <li><a href="logout.php">Cerrar sesión</a></li>
            </ul>
        </div>
    </nav>

    <ul id="dropdown1" class="dropdown-content colorDropdown">
        <li><a href="crud.php">Registro</a></li>
        <li class="divider"></li>
        <li><a href="#!">three</a></li>
    </ul>

    <ul id="dropdown2" class="dropdown-content colorDropdown">
        <li><a href="crud.php">Registro</a></li>
        <li class="divider"></li>
        <li><a href="#!">three</a></li>
    </ul>

    <ul class="sidenav" id="mobile-demo">
        <li>
            <div class="user-view">
                <a href="#user" class="LogoSidebar"><img class="Sidebar" src="./img/logo.png"></a>
                <a href="#name"><span class="white-text name"><?php echo htmlspecialchars($nombre_usuario); ?></span></a>
            </div>
        </li>
        <li><a href="index.php">Inicio</a></li>
        <li><a href="dashboard.php">Eventos</a></li>
        <li><a href="inscripciones.php">Inscripciones</a></li>
        <li><a href="resutados.php">Resultados</a></li>
        <li><a href="fechas.php">Fechas</a></li>
        <li><a class="dropdown-trigger" href="#!" data-target="dropdown2">Menu<i class="material-icons right">arrow_drop_down</i></a></li>
        <li><a href="logout.php" class="waves-effect">Cerrar sesión</a></li>
    </ul>
</header>
<main>
    <div class="container table-container">
        <h3 class="center-align">Gestión de Tablas</h3>

        <form method="POST" action="crud.php" class="colorOption">
            <div class="input-field col s12">
                <select name="tabla" id="tabla" onchange="this.form.submit()">
                    <option value="actividades" <?php if ($tabla_seleccionada == 'actividades') echo 'selected'; ?>>Actividades</option>
                    <option value="Equipo" <?php if ($tabla_seleccionada == 'Equipo') echo 'selected'; ?>>Equipo</option>
                    <option value="Escuela" <?php if ($tabla_seleccionada == 'Escuela') echo 'selected'; ?>>Escuela</option>
                    <option value="Fechas" <?php if ($tabla_seleccionada == 'Fechas') echo 'selected'; ?>>Fechas</option>
                    <option value="TipoUsuarios" <?php if ($tabla_seleccionada == 'TipoUsuarios') echo 'selected'; ?>>TipoUsuarios</option>
                    <option value="TipoActividades" <?php if ($tabla_seleccionada == 'TipoActividades') echo 'selected'; ?>>TipoActividades</option>
                    <option value="Curso" <?php if ($tabla_seleccionada == 'Curso') echo 'selected'; ?>>Curso</option>
                    <option value="Nivel" <?php if ($tabla_seleccionada == 'Nivel') echo 'selected'; ?>>Nivel</option>
                    <option value="eventos" <?php if ($tabla_seleccionada == 'eventos') echo 'selected'; ?>>Eventos</option>
                    <option value="resultados" <?php if ($tabla_seleccionada == 'resultados') echo 'selected'; ?>>Resultados</option>
                </select>
                <label>Selecciona la tabla que deseas gestionar:</label>
            </div>
        </form>

        <br><br>
        <table class="striped">
            <thead>
                <tr>
                    <?php
                    // Obtener los nombres de las columnas de la tabla seleccionada
                    $columnas = $datos->fetch_fields();
                    foreach ($columnas as $columna) {
                        echo "<th>" . htmlspecialchars($columna->name) . "</th>";
                    }
                    ?>
                    <th>Acciones</th>
                </tr>
            </thead>
            <tbody>
                <?php
                if ($datos->num_rows > 0) {
                    while ($row = $datos->fetch_assoc()) {
                        echo "<tr>";
                        foreach ($row as $valor) {
                            echo "<td>" . htmlspecialchars($valor) . "</td>";
                        }
                        echo "<td>";
                        // Enlaces para editar y eliminar usando GET
                        echo "<a href='editar_actividad.php?tabla=" . htmlspecialchars($tabla_seleccionada) . "&id=" . htmlspecialchars($row['id']) . "' class='btn-small waves-effect waves-light' target='_blank'>Editar</a>";
                        echo "<form method='POST' action='crud.php' style='display: inline; margin-left: 10px;'>";
                        echo "<input type='hidden' name='tabla' value='" . htmlspecialchars($tabla_seleccionada) . "'>";
                        echo "<input type='hidden' name='id' value='" . htmlspecialchars($row['id']) . "'>";
                        echo "<input type='hidden' name='accion' value='eliminar'>";
                        echo "<button type='submit' class='btn-small waves-effect waves-light red darken-2'>Eliminar</button>";
                        echo "</form>";
                        echo "</td>";
                        echo "</tr>";
                    }
                } else {
                    echo "<tr><td colspan='" . (count($columnas) + 1) . "' class='center-align'>No hay datos disponibles.</td></tr>";
                }
                ?>
            </tbody>
        </table>
        <br>
        <a href="crear_registro.php?tabla=<?php echo htmlspecialchars($tabla_seleccionada); ?>" class="btn waves-effect waves-light" target="_blank">Crear Nuevo Registro</a>

    </div>
</main>

<footer class="footerColor footerContainer">
    <div class="container footerContainer">
        <div class="row footerColor center footerContainer">
            <div class="col l6 s12">
                <a href="index.php" class="brand-logo">
                    <div class="logofooterDiv">
                        <img src="./img/logo.png" alt="Logo San Jose" class="logofooter">
                        <span class="username"><h5 class="amber-text text-accent-3">Colegio de San José</h5></span>
                    </div>
                </a>
                <p class="grey-text text-lighten-4">Independencia 302. X5000 - Córdoba Argentina</p>
            </div>
            <div class="col l4 offset-l2 s12">
                <h6 class="white-text">0351 - 4223428</h6>
                <ul>
                    <li><a class="grey-text text-lighten-3 texto-en-minusculas texto-chico" href="#!">ninicial@colegiodesanjose.edu.ar</a></li>
                    <li><a class="grey-text text-lighten-3 texto-en-minusculas texto-chico" href="#!">nprimario@colegiodesanjose.edu.ar</a></li>
                    <li><a class="grey-text text-lighten-3 texto-en-minusculas texto-chico" href="#!">direccionsecundario@colegiodesanjose.edu.ar</a></li>
                </ul>
            </div>
            <p class="grey-text text-lighten-4">© 2024 Copyright-informatica San José</p>
        </div>
    </div>
</footer>
<script src="https://cdnjs.cloudflare.com/ajax/libs/materialize/1.0.0/js/materialize.min.js"></script>
<script>
document.addEventListener('DOMContentLoaded', function() {
    var sidenavElems = document.querySelectorAll('.sidenav');
    var sidenavInstances = M.Sidenav.init(sidenavElems, {});

    var dropdownElems = document.querySelectorAll('.dropdown-trigger');
    var dropdownInstances = M.Dropdown.init(dropdownElems, {
        hover: false  // Para activar el dropdown al hacer clic
    });

    var selectElems = document.querySelectorAll('select');
    var selectInstances = M.FormSelect.init(selectElems);
});
</script>   
</body>
</html>
<?php
$conn->close();
?>
